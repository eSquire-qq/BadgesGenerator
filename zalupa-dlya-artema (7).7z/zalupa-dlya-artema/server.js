const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const session = require('express-session');

const app = express();
const router = express.Router();
app.use(express.static('/zalupa-dlya-artema/'));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.json());











// Инициализация сессий
app.use(session({
    secret: 'bebra', // Замените на ваше секретное значение
    resave: false,
    saveUninitialized: true,
    rolling: true, // Включение опции rolling
}));









// СТВОРЕННЯ СЕРТИФІКАТУ

app.get('/', (req, res) => {
    if (req.session.username != undefined) {
        res.render('index.ejs');
    } else {
        res.redirect('/login')
    }
});






// ПОШУК СЕРТИФІКАТІВ
app.get('/find', (req, res) => {
    if (req.session.username != undefined) {
        res.render('findCertificate.ejs', { item: true });
    } else {
        res.render('findCertificate.ejs', { item: false });
    }
});






// ПОШУК СЕРТИФІКАТІВ
app.get('/findCertificate', (req, res) => {
    const number = req.query.numberOfCertificate;
    if (req.session.username != undefined) {
        findCertificateByNumber(number, function (element) {
            res.render('findCertificate2.ejs', { item: element, token: true })
        });
    } else {
        findCertificateByNumber(number, function (element) {
            res.render('findCertificate2.ejs', { item: element, token: false })
        });
    }
});









app.post('/save', (req, res) => {
    const data = req.body;
    const number = data.number;
    const fullname = data.fullname;
    const course = data.course;
    const date = data.date;
    const teacher = data.teacher;
    const hours = data.hours;
    saveInfoToDB(number, fullname, course, teacher, date, hours);
});











app.get('/save', (req, res) => {
    // if (req.session.username != undefined) {
    //     res.render('findCertificate.ejs', { item: true });
    // } else {
    //     res.render('findCertificate.ejs', { item: false });
    // }

    res.redirect('/find');
});







// РЕЄСТРАЦІЯ
app.get('/registration', (req, res) => {
    req.session.destroy();
    res.render('registration.ejs')
});











app.post('/registration', async (req, res) => {
    const { login, fullname, password } = req.body;
    saveUserToDB(fullname, login, password);
    res.redirect('/login');
});










// АВТОРИЗАЦІЯ
app.get('/login', (req, res) => {
    req.session.destroy();
    res.render('login.ejs')
});










app.post('/login', async (req, res) => {
    const { login, password } = req.body;
    checkUser(login, password, function (element) {
        if (element) {
            req.session.username = element.username;
            res.redirect('/');
        } else {
            res.redirect('/login?loginError')
        }
    });
});




















app.listen(3000, () => {
    console.log('Server started on port 3000');
});

const { Pool } = require('pg');

// Функция для сохранения пользователя в базу данных
function saveUserToDB(fullname, login, password) {
    const pool = new Pool({
        user: 'root',
        password: '2298',
        host: 'localhost',
        port: 5432,
        database: 'certificatedb'
    });

    pool.query(
        'INSERT INTO users (username, fullname, password) VALUES ($1, $2, $3)',
        [login, fullname, password],
        (error, results) => {
            if (error) {
                console.error('Error registering user:', error);
            }
            pool.end();
        }
    );
}

// Функция для проверки пользователя в базе данных
function checkUser(login, password, callback) {
    const pool = new Pool({
        user: 'root',
        password: '2298',
        host: 'localhost',
        port: 5432,
        database: 'certificatedb'
    });

    const query = 'SELECT * FROM users WHERE username = $1 AND password = $2';
    pool.query(query, [login, password], (error, results) => {
        if (error) {
            console.error(error);
            callback(null);
        } else {
            if (results.rows.length > 0) {
                callback(results.rows[0]);
            } else {
                callback(null);
            }
        }
        pool.end();
    });
}

// Функция для сохранения информации о сертификате в базе данных
function saveInfoToDB(number, fullname, course, teacher, date, hours) {
    const pool = new Pool({
        user: 'root',
        password: '2298',
        host: 'localhost',
        port: 5432,
        database: 'certificatedb'
    });

    pool.query(
        'INSERT INTO certificates (number, name, course, teacher, get_date, hours) VALUES ($1, $2, $3, $4, $5, $6)',
        [number, fullname, course, teacher, date, hours],
        (error, results) => {
            if (error) {
                console.error(error);
            } else {
                console.log('Info has been saved to the database.');
            }
            pool.end();
        }
    );
}

// Функция для поиска сертификата по номеру
function findCertificateByNumber(number, callback) {
    const pool = new Pool({
        user: 'root',
        password: '2298',
        host: 'localhost',
        port: 5432,
        database: 'certificatedb'
    });

    const query = 'SELECT * FROM certificates WHERE number = $1';
    pool.query(query, ['№' + number], (error, results) => {
        if (error) {
            console.error(error);
            callback(null);
        } else {
            if (results.rows.length > 0) {
                callback(results.rows[0]);
            } else {
                callback(null);
            }
        }
        pool.end();
    });
}

















// function saveUserToDB(fullname, login, password) {
//     const connection = mysql.createConnection({
//         host: 'localhost',
//         user: 'root',
//         password: '2298',
//         database: 'certificatedb'
//     });

//     // Вставка пользователя в базу данных
//     connection.query('INSERT INTO users (username, fullname, password) VALUES (?, ?, ?)', [login, fullname, password],
//         (error, results) => {
//             if (error) {
//                 console.error('Error registering user:', error);
//             }
//         });
//     connection.end();

// }





















// function checkUser(login, password, callback) {
//     const connection = mysql.createConnection({
//         host: 'localhost',
//         user: 'root',
//         password: '2298',
//         database: 'certificatedb'
//     });


//     const query = 'SELECT * FROM users WHERE username = ? AND password = ?';
//     connection.execute(query, [login, password], function (err, results, fields) {
//         if (err) throw err;
//         if (results.length > 0) {
//             callback(results[0])
//         } else {
//             callback(null)
//         }

//         connection.end();
//     });

// }

















// //Функція для збереження інформації про сертифікат у бд
// function saveInfoToDB(number, fullname, course, teacher, date, hours) {
//     const connection = mysql.createConnection({
//         host: 'localhost',
//         user: 'root',
//         password: '2298',
//         database: 'certificatedb'
//     });

//     connection.query(
//         'INSERT INTO certificates (number, name, course, teacher, get_date, hours) VALUES (?, ?, ?, ?, ?, ?)',
//         [number, fullname, course, teacher, date, hours],
//         (error, results) => {
//             if (error) {
//                 console.error(error);
//             } else {
//                 console.log('Info has been saved to the database.');
//             }
//         }
//     );
//     connection.end();
// }















// async function findCertificateByNumber(number, callback) {
//     const connection = mysql.createConnection({
//         host: 'localhost',
//         user: 'root',
//         password: '2298',
//         database: 'certificatedb'
//     });

//     const query = 'SELECT * FROM certificates WHERE number = ?';
//     connection.execute(query, ['№' + number], function (err, results, fields) {
//         if (err) throw err;
//         if (results.length > 0) {
//             callback(results[0])
//         } else {
//             callback(null)
//         }

//         connection.end();
//     });
// }